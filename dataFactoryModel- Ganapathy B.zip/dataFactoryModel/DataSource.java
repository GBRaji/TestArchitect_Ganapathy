package dataFactoryModel;

public enum DataSource {
	
	EXCEL,FAKER,HARDCODED;

}
