package dataFactoryModel;

import java.util.Map;

public interface TestDataProvider {
	
	Map<String,String>getData();

}
